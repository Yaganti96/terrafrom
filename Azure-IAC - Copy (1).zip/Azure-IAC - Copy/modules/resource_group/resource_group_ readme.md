# Introduction 
Terraform module to create an Azure Resource Group.

A resource group is a container that holds related resources for an Azure solution. The resource group can include all the resources for the solution, or only those resources that you want to manage as a group


# How to use this module
## Requirements
Terraform 3.13.0  
Azurerm provider  

## Example
follow the process as given in the below example.

module "resource_group" {
 source = "git::https://github.com/CG-CIS/KnowledgeShare.git//Azure-IAC/modules/resource_group"

 resource_group_name = "rg-test"
 location = "EastUS"
 tags = {env = "dev" }
 
}

# Outputs
| Name | Type | Description |
|-|-|-|


# Variables
| Name | Type | Default | Required | Description |
| ------------- | ------------- |------------- | ------------- |------------- |
| resource_group_name | Resource Group name | String | NA | Yes | The name of the resource group in which to create the App Service. |
| location | Location Name | String | NA | Yes | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. |


## default_tags
default tags should be a map as shown below  
```
default_tags = {
    "BusinessUnit"        = "value"
    "CostOwner"           = "value"
    "Environment"         = "value"
    "Owner"               = "value"
    "ServiceNowReference" = "value"
    "Product"             = "value"
}

## important_note 
Azure automatically deletes any Resources nested within the Resource Group when a Resource Group is deleted.

## referance
https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group




