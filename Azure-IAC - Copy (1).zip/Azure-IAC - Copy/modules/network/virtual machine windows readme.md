# Introduction 
Terraform module to create virtual machine.




# How to use this module
## Requirements
Terraform 3.13.0  
Azurerm provider  

## Example
follow the process as given in the below example.

# Outputs
| Name | Type | Description |
|-|-|-|


# Variables
| Name | Type | Default | Required | Description |
| ------------- | ------------- |------------- | ------------- |------------- |
| resource_group_name | Resource Group name | String | NA | Yes | The name of the resource group in which to create the App Service. |
| location | Location Name | String | NA | Yes | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. |
| name | virtual machine name | string | NA | Yes | Virtal Machine name |
| vm_size
| os_publisher
| os_offer 
| os_sku
| os_version
| os_disk_size_gb
| data_disk_size_gb
| data_disk_caching
| admin_username
| admin_password
| generate_password
| store_password_in_key_vault
| enabled_accelerated_networking
| vnet 
| vnet_resource_group
| subnet_name
| static_ip
| static_ip_addr
| add_to_backup
| azpatch_mode
| domain_join
| domain
| asg_resource_group_name
| provision_vm_agent
| allow_extension_operations
| domain_join_username
| domain_join_password
| enable_disk_encryption
| patch_mode 
| vm_lock
| os_disk_name
| data_disk_names
| data_disk_create_options
| data_disk_luns
| nic_name
| ipconfig_name
| license_type
| enable_legacy_vm_module
| storage_account_type
| os_disk_caching
| md_storage_account_type
| enable_disk_encryption_ADE
| type_handler_version
| encrypt_operation
| kv_urienable_ip_forwarding
| kv_id
| kv_key_id
| encryption_algorithm
| volume_type
| multiple_ips
| enable_ip_forwarding
| enable_automatic_updates
| additional_nics
| additional_nic_names
| additional_nic_subnetnames
| availability_set_id


## default_tags
default tags should be a map as shown below  
```
default_tags = {
    "BusinessUnit"        = "value"
    "CostOwner"           = "value"
    "Environment"         = "value"
    "Owner"               = "value"
    "ServiceNowReference" = "value"
    "Product"             = "value"
}


## referance





