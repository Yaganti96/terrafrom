# Introduction 
Terraform module to create an azure vertual network 

Manages a virtual network including any configured subnets. Each subnet can optionally be configured with a security group to be associated with the subnet.

# How to use this module
## Requirements
Terraform 3.13.0  
Azurerm provider  

## Example

follow the process as given in the below example.

module "vnet" {
 source = "git::https://github.com/CG-CIS/KnowledgeShare.git//Azure-IAC/modules/network"

 vnet_name                                             = "vnet-cg-tst"
 location                                              = "eastus"
 resource_group_name                                   = "rg-test"
 address_spaces                                        = ["10.0.0.0/16"]
 #dns_servers                                           = "asd"
 tags                                                  = { env = "DEV" }  
 subnet_names                                          = ["subnet-cg-tst"]
 subnet_prefixes                                       = ["10.0.1.0/24"] 
 #subnet_enforce_private_link_endpoint_network_policies = ""
 #subnet_service_endpoints                              = ""
}


# Outputs
| Name | Type | Description |
|-|-|-|


# Variables
| Name | Type | Default | Required | Description |
| ------------- | ------------- |------------- | ------------- |------------- |
| vnet_name | Storage Vnet name |	String | NA | Yes |	The name of the virtual network. Changing this forces a new resource to be created. |
| resource_group_name | Resource Group name | String | NA | Yes | The name of the resource group in which to create the App Service. |
| location | Location Name | String | NA | Yes | Specifies the supported Azure location where the resource exists. Changing this forces a new resource to be created. |
| address_spaces | | list(string) | NA | Yes | The address space that is used the virtual network. You can supply more than one address space. |
| dns_servers | | list(string) | NA | No | List of IP addresses of DNS servers. |
| subnet_prefixes | | list(string) | NA | Yes | The address prefix to use for the subnet. |
| global_peering_vnet_name | | list(object({ vnet_name = string, vnet_rg = string })) | NA | Yes | The address prefix to use for the subnet. |
| peering_vnet_name | | list(object({ vnet_name = string, vnet_rg = string })) | NA | Peering vnet name |
| subnet_names |  | list(string) | NA | Yes | The ID of the Subnet where this Network Interface should be located in. |
| subnet_enforce_private_link_endpoint_network_policies | |  map(bool) | NA | Yes | A map with key (string) `subnet name`, value (bool) `true` or `false` to indicate enable or disable network policies for the private link endpoint on the subnet. Default value is false |
| subnet_service_endpoints | | map(list(string)) | NA | No | The list of Service endpoints to associate with the subnet. Possible values include: Microsoft.AzureActiveDirectory, Microsoft.AzureCosmosDB, Microsoft.ContainerRegistry, Microsoft.EventHub, Microsoft.KeyVault, Microsoft.ServiceBus, Microsoft.Sql, Microsoft.Storage and Microsoft.Web. | 
| subnet_delegation | | String | NA | Yes | The name of service to delegate to. Possible values include Microsoft.ApiManagement/service, Microsoft.AzureCosmosDB/clusters, Microsoft.BareMetal/AzureVMware, Microsoft.BareMetal/CrayServers, etc. |


## default_tags
default tags should be a map as shown below  
```
default_tags = {
    "BusinessUnit"        = "value"
    "CostOwner"           = "value"
    "Environment"         = "value"
    "Owner"               = "value"
    "ServiceNowReference" = "value"
    "Product"             = "value"
}

## referance
https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/log_analytics_workspace

