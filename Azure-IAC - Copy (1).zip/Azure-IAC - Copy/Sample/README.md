# DEV environment 

Using Dev just for namesake to test out the code and provision resources