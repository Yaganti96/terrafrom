# Introduction

Terraform module to create a resource group.
# How to use this module

## Example

```
resource "azurerm_resource_group" "resource_group" {
  name     = var.rg_name
  location = var.location
}

resource "azurerm_resource_group" "rg_network" {
  name     = var.rg_network
  location = var.location
}

resource "azurerm_resource_group" "rg_secrets" {
  name     = var.rg_secrets
  location = var.location
}

resource "azurerm_resource_group" "rg_logs" {
  name     = var.rg_logs
  location = var.location
}

```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables
| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the resource group |  
| location | String | N/A | yes | The location where the resource group should be provisioned |




<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_resource_group.resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.rg_logs](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.rg_network](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |
| [azurerm_resource_group.rg_secrets](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | description | `string` | `"Norway East"` | no |
| <a name="input_rg_name"></a> [rg\_name](#input\_rg\_name) | description | `string` | `"Test-log"` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_rg"></a> [rg](#output\_rg) | Resource group name |
<!-- END_TF_DOCS -->