# Introduction

Terraform module to create an Azure function app.
# How to use this module

## Example

```
resource "azurerm_function_app" "function_app" {
  name                       = var.function_app.name
  location                   = var.location
  resource_group_name        = var.resource_group
  app_service_plan_id        = var.app_service_plan_id
  storage_account_name       = var.storage_account_name
  storage_account_access_key = var.storage_account_primary_access_key
}

resource "azurerm_app_service_virtual_network_swift_connection" "app_service_connector" {
  app_service_id = azurerm_function_app.function_app.id
  subnet_id      = var.subnet_id
}
```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables

## Function app
| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the function app |  
| location | String | N/A | yes | The Azure location where the function app should be provisioned |
| resource_group_name | String | N/A | yes | The name of the Resource Group in which the function app should be exist |
| app_service_plan_id | String | N/A | yes | The ID of the App Service Plan connected to the function app |
| storage_account_name | String | N/A | yes | The storage account name the function app is connected to |  
| storage_account_access_key | String | N/A | yes | The storage account access key the function app uses to connect to the storage account|  

## Function app swift connection
| app_service_id | String | N/A | yes | The name of the function app the virtual network connection should connect |  
| subnet_id | String | N/A | yes | The id of the subnet the function app should exist in |  



<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_function_app.function_app](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/function_app) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_service_plan_id"></a> [app\_service\_plan\_id](#input\_app\_service\_plan\_id) | n/a | `string` | n/a | yes |
| <a name="input_function_app"></a> [function\_app](#input\_function\_app) | n/a | <pre>object({<br>      name = string<br>    })</pre> | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | n/a | `string` | n/a | yes |
| <a name="input_storage_account_name"></a> [storage\_account\_name](#input\_storage\_account\_name) | n/a | `string` | n/a | yes |
| <a name="input_storage_account_primary_access_key"></a> [storage\_account\_primary\_access\_key](#input\_storage\_account\_primary\_access\_key) | n/a | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_function_app_id"></a> [function\_app\_id](#output\_function\_app\_id) | function app id |
<!-- END_TF_DOCS -->