# Introduction

Terraform module to create an Azure container registry.

# How to use this module

## Example

```
#&nbsp;since these variables are re-used - a locals block makes this more maintainable

resource "azurerm_container_registry" "acr" {
    name                = var.acr.name
    resource_group_name = var.resource_group.name
    location            = var.location
    sku                 = var.acr.sku
    admin_enabled       = var.acr.admin_enabled
    
}
```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables
| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the Azure container registry |  
| location | String | N/A | yes | The Azure location where the container registry should be provisioned |
| resource_group_name | String | N/A | yes | The name of the Resource Group in which the container registry should be exist |
| admin_enabled | String | N/A | yes | Enable admin for azure container registry |  






<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_container_registry.acr](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/container_registry) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_acr"></a> [acr](#input\_acr) | n/a | <pre>object({<br>        name = string<br>        sku = string<br>        admin_enabled = bool<br>    })</pre> | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | n/a | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->