# Introduction

Terraform module to create a route table association

# How to use this module

## Example

```
resource "azurerm_route_table" "default_route" {
    name = var.default_route_table.name
    location  = var.location
    resource_group_name = var.resource_group.name
    disable_bgp_route_propagation = var.default_route_table.disable_bgp_route_propagation 

  route {
    name           = var.default_route_table.route.name
    address_prefix = var.default_route_table.route.address_prefix 
    next_hop_type  = var.default_route_table.route.next_hop_type 
    next_hop_in_ip_address = var.default_route_table.route.next_hop_in_ip_address
  }
}

```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables
| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the default route table name |  
| location | String | N/A | yes | The location where the route table should be provisioned |
| resource_group_name | String | N/A | yes | The name of the Resource Group in which the route table should be provisioned |
| disable_bgp_route_propagation | boolean | N/A | yes | Value to decide if route propagation should be disabled or enabled |  

## route
| name | String | N/A | yes | The name of the default route table |  
| address_prefix | String | N/A | yes | The address prefix the route table should use |  
| next_hop_type | String | N/A | yes | The name of the default route table name |  
| next_hop_in_ip_address | String | N/A | yes | The name of the default route table name |  







<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_route_table.default_route](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/route_table) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_default_route_table"></a> [default\_route\_table](#input\_default\_route\_table) | n/a | <pre>object ({<br>    name = string<br>    disable_bgp_route_propagation = bool<br><br>    route = object({<br>      name = string<br>      address_prefix = string<br>      next_hop_type = string<br>      next_hop_in_ip_address = string<br>    })<br>  })</pre> | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | n/a | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_route_tables"></a> [route\_tables](#output\_route\_tables) | n/a |
<!-- END_TF_DOCS -->