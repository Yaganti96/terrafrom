<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_api_management_product.product](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management_product) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_api_management_name"></a> [api\_management\_name](#input\_api\_management\_name) | APIM name | `string` | n/a | yes |
| <a name="input_description"></a> [description](#input\_description) | product description | `string` | n/a | yes |
| <a name="input_display_name"></a> [display\_name](#input\_display\_name) | Api display name | `string` | n/a | yes |
| <a name="input_product_name"></a> [product\_name](#input\_product\_name) | Apim product id | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | Resource group name | `string` | n/a | yes |
| <a name="subscription_required"></a> [subscription_required](#input\_display\_name) | Subscription requerd? | `bool` | true | No |
| <a name="approval_required"></a> [approval_required](#input\_product\_name) | Approval requierd? | `bool` | true | No |
| <a name="published"></a> [published](#input\_resource\_group\_name) | Is this product published? | `bool` | true | No |


## Outputs

| Name | Description |
|------|-------------|
| <a name="output_product_name"></a> [product\_name](#output\_product\_name) | APIM product id |
<!-- END_TF_DOCS -->