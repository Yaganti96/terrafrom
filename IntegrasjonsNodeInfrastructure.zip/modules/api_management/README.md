# Introduction

Terraform module to create an Azure API management.

# How to use this module

## Example

```
module "api_management" {
  source = "git@ssh.dev.azure.com:v3/AzureNortura/AzureCloudFoundation/IntegrasjonsNodeInfrastructure.git//Module/api_management"

  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group.name
  publisher_name      = var.publisher_name
  publisher_email     = var.publisher_email
  sku_name            = var.sku_name
}
```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables

| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the API Management Service |  
| location | String | N/A | yes | The Azure location where the API Management Service exists |
| resource_group_name | String | N/A | yes | The name of the Resource Group in which the API Management Service should be exist |
| publisher_name | String | N/A | yes | The name of publisher or company |
| publisher_email | String | N/A | yes |The email of publisher or company| |  
| sku_name | String | N/A | yes | The sku name for the API Management Service|  

<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_api_management.api_management](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/api_management) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | api management location | `string` | n/a | yes |
| <a name="input_name"></a> [name](#input\_name) | api management name | `string` | n/a | yes |
| <a name="input_publisher_email"></a> [publisher\_email](#input\_publisher\_email) | api management publisher email | `string` | n/a | yes |
| <a name="input_publisher_name"></a> [publisher\_name](#input\_publisher\_name) | api management publisher name | `string` | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | api management resource group name | `string` | n/a | yes |
| <a name="input_sku_name"></a> [sku\_name](#input\_sku\_name) | api management sku name | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->