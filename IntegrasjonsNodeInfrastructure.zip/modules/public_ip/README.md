# Introduction

Terraform module to create an public ip.
# How to use this module

## Example

```
resource "azurerm_public_ip" "public_ip" {
  name                = var.public_ip.name
  location            = var.location
  resource_group_name = var.rg_name
  allocation_method   = var.public_ip.allocation_method
  sku                 = var.public_ip.sku
}

```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables
| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the public ip resource |  
| location | String | N/A | yes | The location where the public ip should be provisioned |
| resource_group_name | String | N/A | yes | The name of the Resource Group in which the public IP should be provisioned |
| allocation_method | String | N/A | yes | the allocation method of the public ip |
| sku | String | N/A | yes | The sku of the public ip resource |  



<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_public_ip.public_ip](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/public_ip) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | description | `string` | `"norwayeast"` | no |
| <a name="input_public_ip"></a> [public\_ip](#input\_public\_ip) | n/a | <pre>object({<br>    name              = string<br>    allocation_method = string<br>    sku               = string<br>  })</pre> | n/a | yes |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | n/a | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_public_ip"></a> [public\_ip](#output\_public\_ip) | Public IP Object |
<!-- END_TF_DOCS -->