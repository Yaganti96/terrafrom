# Introduction

Terraform module to create the subnet for integration node

# How to use this module

## Example

```
resource "azurerm_virtual_network" "vnet" {
  name                = var.virtual_network_config.name
  location            = var.location
  resource_group_name = var.resource_group.name
  address_space       = var.virtual_network_config.address_space
  dns_servers         = var.virtual_network_config.dns_servers

  tags = {
    environment = var.virtual_network_config.environment
  }
}


```

# Outputs

| Name | Type | Description |
|-|-|-|


# subnet
| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the vnet |  
| location | String | N/A | yes | The location of where the vnet is provisioned |  
| resource_group_name | String | N/A | yes | The name of the Resource Group in which the vnet should be provisioned |
| address_space | String | N/A | yes | The address prefixes to use for the virtual network |  
| dns_servers | String | N/A | yes | The dns server to use for the virtual network |  
| environment | String | N/A | yes | The environment which the vnet is provisioned to |  





<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_virtual_network.vnet](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/virtual_network) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | n/a | `string` | n/a | yes |
| <a name="input_virtual_network_config"></a> [virtual\_network\_config](#input\_virtual\_network\_config) | n/a | <pre>object({<br>      name=string,<br>      address_space=list(string),<br>      dns_servers = list(string),<br>      environment = string<br>    })</pre> | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_virtual_network_config"></a> [virtual\_network\_config](#output\_virtual\_network\_config) | Resource group name secrets |
<!-- END_TF_DOCS -->