# Introduction

Terraform module to create an container registry.

# How to use this module

## Example

```
#&nbsp;since these variables are re-used - a locals block makes this more maintainable

resource "azurerm_eventhub_namespace" "eventhub_namespace" {
  name                = var.eventhub_namespace.name
  location            = var.location
  resource_group_name = var.resource_group.name
  sku                 = var.eventhub_namespace.sku
  capacity            = var.eventhub_namespace.capacity


  network_rulesets {
    default_action = var.eventhub_default_action
    virtual_network_rule {
      subnet_id = var.subnet_id
    }
  }

  tags = {
    environment = var.eventhub_namespace_env
  }
}
```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables
| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the eventhub namespace |  
| location | String | N/A | yes | The location of the eventhub namespace |
| resource_group_name | String | N/A | yes | the resource group name where the eventhub is located |
| sku | String | N/A | yes | The sku for the eventhub namespace |  
| capacity | String | N/A | yes | The capacity of the eventhub namespace |  

## network ruleset
| default_action | String | N/A | yes | The default action of the eventhub namespace (default is deny) |  

## virtual network rule
| subnet_id | String | N/A | yes | The subnet the eventhub namespace should be located in |  
| tags | String | N/A | yes | The tags of the eventhub namespace |  









<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_eventhub_namespace.eventhub_namespace](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/eventhub_namespace) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_eventhub_default_action"></a> [eventhub\_default\_action](#input\_eventhub\_default\_action) | n/a | `string` | n/a | yes |
| <a name="input_eventhub_namespace"></a> [eventhub\_namespace](#input\_eventhub\_namespace) | n/a | <pre>object({<br>        name = string<br>        sku  = string<br>        capacity = number<br>    })</pre> | n/a | yes |
| <a name="input_eventhub_namespace_env"></a> [eventhub\_namespace\_env](#input\_eventhub\_namespace\_env) | n/a | `string` | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | n/a | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->