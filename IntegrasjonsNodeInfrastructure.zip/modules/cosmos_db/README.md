# Introduction

Terraform module to create an Azure app service.

# How to use this module

## Example

```
resource "azurerm_cosmosdb_account" "cosmos_db" {
    name  = var.cosmos_db_configuration.name
    resource_group_name = var.resource_group.name
    location = var.location
    offer_type = var.cosmos_db_configuration.offer_type

    consistency_policy {
        consistency_level       = var.cosmos_db_consistency_policy.consistency_level
        max_interval_in_seconds = var.cosmos_db_consistency_policy.max_interval_in_seconds
        max_staleness_prefix    = var.cosmos_db_consistency_policy.max_staleness_prefix
    }

    geo_location {
        location          = var.cosmos_db_geo_location.location
        failover_priority = var.cosmos_db_geo_location.failover_priority
    }

}
resource "azurerm_cosmosdb_sql_database" "cosmos_db_sql" {
  name                = var.cosmos_db_config_sql.name
  resource_group_name = azurerm_cosmosdb_account.cosmos_db.resource_group_name
  account_name        = azurerm_cosmosdb_account.cosmos_db.name
  throughput          = var.cosmos_db_config_sql.throughput
}

```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables

| Name | Type | Default | Required | Description |
| cosmos db account      |-|-|-|-|
| name | String | N/A | yes | The name of the cosmos Service |  
| location | String | N/A | yes | The Azure location where the Cosmos dvb instance should be provisioned |
| resource_group_name | String | N/A | yes | The name of the Resource Group in which the cosmos db instance should be exist |
| offer_type | String | N/A | yes | The offer type of the cosmos db instance also known as SKU eks: standard |

| consistency policy | Object | N/A | yes | The policy for the database on how strict the data should be delivered |
| consistency_level | String | N/A | yes |The level of the consistency type of the database (strong, boundedStaleness, session, consistent prefix, eventual ) | |  
| max_interval_in_seconds | String | N/A | yes | The highest amount of stale operations per seconds - tied to boundedstaleness | 
| max_staleness_prefix | Object | N/A | yes | The number of stale requests (not per seconds) - tied to boundedStaleness |
| geolocation | object | N/A | yes | Object for defining the possible replication to other geo-locations |
| location | String | N/A | yes | where to replicate | |  
| failover_priority | String | N/A | yes | priority on this replication (with multiple the priority can be important) |  
<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_cosmosdb_account.cosmos_db](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/cosmosdb_account) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_cosmos_db_configuration"></a> [cosmos\_db\_configuration](#input\_cosmos\_db\_configuration) | n/a | <pre>object({<br>    name = string<br>    offer_type = string<br>  })</pre> | n/a | yes |
| <a name="input_cosmos_db_consistency_policy"></a> [cosmos\_db\_consistency\_policy](#input\_cosmos\_db\_consistency\_policy) | n/a | <pre>object({<br>        consistency_level = string<br>        max_interval_in_seconds = number<br>        max_staleness_prefix = number<br>    })</pre> | n/a | yes |
| <a name="input_cosmos_db_geo_location"></a> [cosmos\_db\_geo\_location](#input\_cosmos\_db\_geo\_location) | n/a | <pre>object({<br>        location = string<br>        failover_priority = number<br>    })</pre> | n/a | yes |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | n/a | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | n/a | yes |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_cosmos_db_name"></a> [cosmos\_db\_name](#output\_cosmos\_db\_name) | cosmos db account name |
<!-- END_TF_DOCS -->