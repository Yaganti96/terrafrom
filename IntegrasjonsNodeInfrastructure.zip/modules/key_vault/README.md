# Introduction

Terraform module to create an azure keyvault.

# How to use this module

## Example

```
resource "azurerm_key_vault" "key_vault" {
  name                        = var.key_vault.name
  location                    = var.location
  resource_group_name         = var.resource_group
  enabled_for_disk_encryption = var.key_vault.enabled_for_disk_encryption
  tenant_id                   = var.tenant_id
  soft_delete_retention_days  = var.key_vault.soft_delete_retention_days
  purge_protection_enabled    = var.key_vault.purge_protection_enabled

  sku_name = var.key_vault.sku_name

  network_acls {
    bypass = var.bypass
    default_action = var.keyvault_default_action
    virtual_network_subnet_ids = [ var.subnet_id ]
  }
}


```

# Outputs

| Name | Type | Description |
|-|-|-|


# Variables

| Name | Type | Default | Required | Description |
|-|-|-|-|-|
| name | String | N/A | yes | The name of the key vault |  
| location | String | N/A | yes | The Azure location where the keyvault should be provisioned |
| resource_group_name | String | N/A | yes | The name of the Resource Group where the key vault should be created |
| enabled_for_disk_encryption | boolean | N/A | yes | If the key vault should be enabled for disk encryption |  
| tenant id | String | N/A | yes | The id of the tenant the key vault should be created |  
| soft_delete_retention_days | String | N/A | int | the number of days of deleted key retention. |  
| purge_proection_enabled | boolean | N/A | yes | if the keyvault should have purge protection or not |  
| sku_name | String | N/A | yes | The name of the sku the keyvault should use |  


## Network acls
| bypass | String | N/A | yes | The bypass rules for the keyvault |  
| default_action | String | N/A | yes | The default auction of the keyvault default: deny, action to use when ip_rules dont match |  
|  virtual_network_subnet_ids | List | N/A | yes | the keyvaults virtual network subnet ids that can access this keyvault |  



<!-- BEGIN_TF_DOCS -->
## Requirements

No requirements.

## Providers

| Name | Version |
|------|---------|
| <a name="provider_azurerm"></a> [azurerm](#provider\_azurerm) | n/a |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [azurerm_key_vault.key_vault](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault) | resource |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_bypass"></a> [bypass](#input\_bypass) | n/a | `string` | n/a | yes |
| <a name="input_key_vault"></a> [key\_vault](#input\_key\_vault) | n/a | <pre>object({<br>    name = string<br>    enabled_for_disk_encryption = bool<br>    soft_delete_retention_days  = number<br>    purge_protection_enabled    = bool<br>    sku_name = string<br>  })</pre> | `null` | no |
| <a name="input_keyvault_default_action"></a> [keyvault\_default\_action](#input\_keyvault\_default\_action) | n/a | `string` | `"Deny"` | no |
| <a name="input_location"></a> [location](#input\_location) | n/a | `string` | n/a | yes |
| <a name="input_resource_group"></a> [resource\_group](#input\_resource\_group) | n/a | `string` | n/a | yes |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | n/a | `string` | n/a | yes |
| <a name="input_tenant_id"></a> [tenant\_id](#input\_tenant\_id) | n/a | `string` | n/a | yes |

## Outputs

No outputs.
<!-- END_TF_DOCS -->