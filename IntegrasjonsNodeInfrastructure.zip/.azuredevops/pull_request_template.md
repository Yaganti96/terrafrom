# Description of work
Replace this section with a descripton of your work

# Jira task/ticket for work done
Add your jira ticket number here if relevant

# Affected repositories for validation
List the affected repositories here:

# Tasks
## For the developer
- [ ] Ensure that `terraform fmt --recursive` has been run from the repository root
- [ ] Ensure that `terraform validate` has been run from affected repositories
- [ ] Ensure that the module README file has been updated with the relevant changes

## For the reviewer
- [ ] Ensure that `terraform fmt --recursive` has been run from the repository root
- [ ] Ensure that `terraform validate` has been run from affected repositories
- [ ] Ensure that the module README file has been updated with the relevant changes
